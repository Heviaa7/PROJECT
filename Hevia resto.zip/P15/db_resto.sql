-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2024 at 07:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_resto`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `kode_menu` int(20) NOT NULL,
  `nama_menu` varchar(20) NOT NULL,
  `harga_menu` decimal(10,2) NOT NULL,
  `stok` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`kode_menu`, `nama_menu`, `harga_menu`, `stok`) VALUES
(1, 'Ayam Rendang', 20000.00, 20),
(2, 'Ikan Bakar', 10000.00, 23),
(9, 'Pecel', 8000.00, 21),
(11, 'Seblak', 7000.00, 30);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `kode_order` int(20) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `pelayan` varchar(20) NOT NULL,
  `no_meja` int(50) NOT NULL,
  `status` enum('proses','selesai','batal','') NOT NULL,
  `pembeli` varchar(100) NOT NULL,
  `total_bayar` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`kode_order`, `tanggal`, `jam`, `pelayan`, `no_meja`, `status`, `pembeli`, `total_bayar`) VALUES
(138, '2024-02-08', '10:33:40', 'Miya', 1, 'proses', 'umum', 40000.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_detil`
--

CREATE TABLE `order_detil` (
  `id_detil` bigint(100) NOT NULL,
  `kode_order` int(100) NOT NULL,
  `kode_menu` int(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `harga_menu` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_detil`
--

INSERT INTO `order_detil` (`id_detil`, `kode_order`, `kode_menu`, `jumlah`, `harga_menu`, `subtotal`) VALUES
(143, 138, 2, 2, 10000.00, 20000.00),
(145, 138, 2, 2, 10000.00, 20000.00);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `hp` varchar(30) NOT NULL,
  `alamat` text NOT NULL,
  `level` enum('1','2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `nama`, `password`, `hp`, `alamat`, `level`) VALUES
(1, 'hevia', 'Hevia', 'hevi1', '082736452635', 'Bandung', '1'),
(2, 'revika', 'Revika', 'hevi2', '087657636543', 'Jakarta', '2'),
(3, 'putri', 'Putri', 'hevi3', '075847364859', 'Depok', '2'),
(4, 'miya', 'Miya', 'hevi4', '087342167587', 'Cirebon', '2'),
(5, 'selena', 'Selena', 'hevi5', '085654354786', 'Bogor', '2'),
(6, 'wanwan', 'Wanwan', 'hevi6', '0873945867364', 'Solo', '2'),
(7, 'layla', 'Layla', 'hevi7', '075645364756', 'Lampung', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`kode_menu`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`kode_order`);

--
-- Indexes for table `order_detil`
--
ALTER TABLE `order_detil`
  ADD PRIMARY KEY (`id_detil`),
  ADD KEY `order_detil_ibfk_1` (`kode_order`),
  ADD KEY `order_detil_ibfk_2` (`kode_menu`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `kode_menu` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `kode_order` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT for table `order_detil`
--
ALTER TABLE `order_detil`
  MODIFY `id_detil` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_detil`
--
ALTER TABLE `order_detil`
  ADD CONSTRAINT `order_detil_ibfk_1` FOREIGN KEY (`kode_order`) REFERENCES `order` (`kode_order`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_detil_ibfk_2` FOREIGN KEY (`kode_menu`) REFERENCES `menu` (`kode_menu`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
