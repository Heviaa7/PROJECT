<?php
session_start();
include "koneksi.php";

if (isset($_GET['kode_order'])) {
    $kode_order = $_GET['kode_order'];
} else {
    $kode_order = "";
    echo "<h1>Order Invalid</h1>";
}

if (isset($_POST['kirim'])) {
    $kode_order = $_POST['kode_order'];
    $kode_menu = $_POST['kode_menu'];
    $jumlah = $_POST['jumlah'];

    // MENGOLAH  STOK
    $sql_stok = "SELECT stok FROM menu WHERE kode_menu = '$kode_menu'";
    $query_stok = mysqli_query($koneksi, $sql_stok);
    $row_stok = mysqli_fetch_assoc($query_stok);
    $stok = $row_stok['stok'];

    $new_stok = $stok - $jumlah;
    $sql_update_stok = "UPDATE menu SET stok = '$new_stok' WHERE kode_menu = '$kode_menu'";
    $query_update_stok = mysqli_query($koneksi, $sql_update_stok);

    // Dapatkan harga_menu dari database berdasarkan kode_menu
    $query_harga = "SELECT harga_menu FROM menu WHERE kode_menu = '$kode_menu'";
    $result_harga = mysqli_query($koneksi, $query_harga);

    if ($result_harga && mysqli_num_rows($result_harga) > 0) {
        $row_harga = mysqli_fetch_assoc($result_harga);
        $harga_menu = $row_harga['harga_menu'];

        // Hitung subtotal
        $subtotal = $harga_menu * $jumlah;

        // Masukkan data ke dalam tabel
        $query_insert = "INSERT INTO order_detil (kode_order, kode_menu, harga_menu, jumlah, subtotal) 
                        VALUES ('$kode_order', '$kode_menu', '$harga_menu', '$jumlah', '$subtotal')";

        $hasil_insert = mysqli_query($koneksi, $query_insert);

         // Hitung Total Bayar
        $sql_total_bayar = "SELECT SUM(subtotal) as total_bayar FROM order_detil WHERE kode_order = '$kode_order'";
        $query_total_bayar = mysqli_query($koneksi, $sql_total_bayar);

        if($query_total_bayar){
            $row_total_bayar = mysqli_fetch_assoc($query_total_bayar);
            $total_bayar = $row_total_bayar['total_bayar'];
            $sql_update_bayar = "UPDATE `order` SET  total_bayar = '$total_bayar' WHERE kode_order = '$kode_order'";
            $query_update_bayar  = mysqli_query($koneksi, $sql_update_bayar); 
        }
    }
}

$sql_catatan = "SELECT * FROM order_detil 
                INNER JOIN menu ON menu.kode_menu = order_detil.kode_menu WHERE kode_order = '$kode_order'";
$query_catatan = mysqli_query($koneksi, $sql_catatan);
$no = 1

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ORDER</title>
    <link rel="stylesheet" href="gambar.css">
    <style>
        * {font-family: Arial, sans-serif;}
        body{
            background-image: url(home.jpg);
            background-size: cover;
            color: white;
            padding:  0 0 20px 0;
            text-align: center;
        }
        header h1 {
            text-align: center;
            color: white;
            font-size: 50px;
        }
        header h5{text-align: center; padding-bottom: 10px; color: white;}
        main{
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        fieldset{
            width: 400px;
            color: azure;
        }
        form input, form select{
            width: 120%;
            padding: 5px;
            border: 1px solid #000; /* Tambahkan border */
            margin-bottom: 7px; /* Tambahkan jarak antara elemen input */
        }
        form input[type="submit"]{
            background-color: burlywood;
            border-radius: 10px;
            box-shadow: 5px 5px 10px rgba(230, 221, 221, 0.5);
            margin-top: 10px;
        }
        form table{
            margin:0 20% 0 15%;
            width : 60%;
            margin-top: 10px;
        }
        .catatan_pesan{
            color: white;
            text-align: center;
        }

        .catatan_pesan th, 
        .catatan_pesan td{
            border: 1px solid white;
            padding: 7px;
        }
        button{
            background-color: rgb(240, 219, 193);
            background-color: burlywood;
            padding: 10px 20px;
            font-size: 20px;
            border-radius: 10px;
            box-shadow: 5px 5px 10px rgba(230, 221, 221, 0.5);
        }
        .button-selesai{text-align: center; padding-top: 0px;}
        .notif{color: white; text-align: center;}
    </style>
</head>
<body>
    <?php 
    include "koneksi.php";
    
    if ($_SESSION['level'] == 1){
        include "navbar.php";
    }elseif($_SESSION['level'] == 2){
        include "navbar_2.php";
    }
    ?><br>
    <header>
        <h1>Tambah Pesanan</h1>
        <h5>ID Order : <?php echo "$kode_order ";?></h5>
    </header><br>

    <main>
        <div class="form">  
            <fieldset class="border p-2">
            <form action="" method="post">
                <table>
                    <tr>
                        <td><input type="hidden" id="kode_order" name = "kode_order" value="<?php echo $kode_order ?>"></td>
                    </tr>

                    <tr>
                        <td><label for="menu"><b>Menu<b></label></td>
                        <td><select name="kode_menu" id="menu" required>
                        <option value=""disable selected> -- Pilih Menu --</option>
                            <?php
                                include "koneksi.php";
                                $sql = "SELECT kode_menu, CONCAT(nama_menu, ' / ', harga_menu) AS ket FROM menu ORDER BY nama_menu";
                                $result = mysqli_query($koneksi, $sql);
                                if ($result && mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo '<option value = "'. $row['kode_menu'].'">'.$row['ket'].'</option>';
                                    }
                                }
                                ?>
                        </select></td>
                    </tr>

                    <tr>
                        <td><label for="jumlah"><b>Jumlah<b></label></td>
                        <td><input type="number" id="jumlah" placeholder="jumlah" name="jumlah" required></td>
                    </tr>
                    
                    <tr>
                        <td></td>
                        <td colspan="2"><input type="submit" value="Simpan Pesanan" name="kirim"></td>
                    </tr>
                </table>
            </form>
            </fieldset>   
        </div>

        <div class="catatan_pesan">
            <table border='1'>
                <tr>
                    <th>No</th>
                    <th>Item</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
                
                <?php
                while ($row = mysqli_fetch_array($query_catatan)){?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $row['nama_menu'] ?></td>
                            <td><?= $row['jumlah'] ?></td>
                            <td><?= "Rp " . number_format($row['harga_menu'], 2, ',', '.') ?></td>
                            <td><?= "Rp " . number_format($row['subtotal'], 2, ',', '.') ?></td>
                            <td>
                                <a href="?id_detil=<?= $row['id_detil'] ?>&kode_order=<?= $kode_order ?>" onclick="return confirm('Anda yakin ingin membatalkan Data Order ini?')">
                                    <button class="btn btn-danger">Hapus</button>
                                </a>
                            </td>

                        </tr>
                <?php
                    $no++;
                }

                $sql_bayar = "SELECT total_bayar FROM `order` WHERE kode_order = '$kode_order'";
                $query_bayar = mysqli_query($koneksi, $sql_bayar);
                $bayar = mysqli_fetch_assoc($query_bayar);
                $total_bayar = $bayar['total_bayar'];
                $total_bayar_formatted = "Rp " . number_format($total_bayar, 2, ',', '.');
                ?>
                <tr>
                    <td colspan="3">Total Bayar</td>
                    <td colspan="3"><?= $total_bayar_formatted ?></td>
                </tr>
            </table>

        </div>
    </main>

    <br><br>
    <div class="button-selesai">
        <button type="button" onclick="window.location.href = '5_dataOrder.php'">Selesai</button>
    </div>

    <div class="gambar">
        <img src="ayam.jpg" alt="ayam bakar">
        <img src="ikan.jpg" alt="ikan bakar">
        <img src="sate.jpg" alt="sate ayam">
        <img src="sosis.jpg" alt="sosis bakar">
        <img src="soto.jpg" alt="soto ayam">
    </div>
</body>
</html>

<?php
// HAPUS PESANAN MENU
if(isset($_GET['id_detil'])){
    $id_detil = $_GET['id_detil'];
    $kode_order = $_GET['kode_order'];

    // INNER JOIN MENU DAN ORDER_DETIL
    $sql_inner = "SELECT * FROM order_detil INNER JOIN menu 
                ON menu.kode_menu = order_detil.kode_menu WHERE order_detil.id_detil = '$id_detil'";
    $query_inner = mysqli_query($koneksi, $sql_inner);
    $row_inner = mysqli_fetch_assoc($query_inner);

     // MENGOLAH STOK SETELAH DI HAPUS MENU
     $sql_update_stuk = "UPDATE menu SET stok = stok + '$row_inner[jumlah]' WHERE kode_menu = '$row[kode_menu]'";
     $query_update_stuk = mysqli_query($koneksi, $sql_update_stuk);

    // SUBTOTAL
    $subtotal = $row_inner['subtotal'];

    // CARI TOTAL BAYAR
    $sql_total = "SELECT total_bayar FROM `order` WHERE kode_order = '$kode_order'";
    $query_total = mysqli_query($koneksi, $sql_total);
    $row_total = mysqli_fetch_assoc($query_total);
    $total_bayar = $row_total['total_bayar'];

    // UPDATE TOTAL BAYAR
    $total_bayar_new = $total_bayar - $subtotal;
    $update_bayar = "UPDATE `order` SET total_bayar = '$total_bayar_new' WHERE kode_order = '$kode_order'";
    $query = mysqli_query($koneksi, $update_bayar);

    // HAPUS
    $sql_hapus  = "DELETE FROM order_detil WHERE id_detil = '$id_detil'";
    $query_hapus = mysqli_query($koneksi, $sql_hapus);
    if($query_hapus){
        echo "<script> alert('Menu Pesanan Berhasil Dihapus') </script>";
        echo "<script> window.location.href='2_pesan2.php?kode_order=$kode_order' </script>";

        
    }
}
