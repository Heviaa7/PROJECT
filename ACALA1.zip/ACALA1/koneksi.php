<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "acala";

$koneksi = mysqli_connect($hostname, $username, $password, $database);
?>