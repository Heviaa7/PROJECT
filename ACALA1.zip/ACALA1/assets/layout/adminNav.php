<div class="topbar">            
    <div class="toggle">
        <ion-icon name="menu-outline"></ion-icon>
    </div>

    <div class="user">
        <img src="assets/img/logo.jpeg" alt="" >
    </div>
</div>

<!-- <div class="container-fluid d-flex justify-content-between">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item dropdown">
                <img src="img/logo.jpeg" alt="" >
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </div> -->